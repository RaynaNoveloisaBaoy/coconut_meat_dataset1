
perfectly-cooked coconut meat - v5 Final Annotated Dataset
==============================

This dataset was exported via roboflow.ai on May 15, 2022 at 10:42 AM GMT

It includes 371 images.
Perfectly-cooked are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Fit (white edges))

The following augmentation was applied to create 3 versions of each source image:
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise


